APPLICATION NOTE "AN3954 : CR95HF Demo Kit source code"

revision 1.0	(07/2011)
	- VB OK
	- C/C++ OK
	Pas de fichier readme.txt (revision) dans le premier dossier ZIP
	
revision 2.0	(11/2011)
	- DLL 0.5 added
	- USB Connect & new functions added
	
revision 3.0	(10/2012)
	- Updated following AN3954 application note revision 3
	- DLL 0.9 added
	- CR95HFDLL_GetHardwareVersion function added
	- Iso14443B protocol select updated following datasheet
	
09/13
	- change file name from stsw-m24lr005 to stsw-95hf002
	- no other change